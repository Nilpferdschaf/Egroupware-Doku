<?php
header('Location: ../index.php?menuaction=helloworld.helloworld_ui.index');